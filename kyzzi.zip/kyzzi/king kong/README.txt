Kyzzi Pro
=========
1. Unzip this folder.
2. Double-click Setup-Kyzzi.bat (or open Open-Me.html for the illustrated steps).
3. Kyzzi starts with Pro already unlocked (kyzzi.key).

Your key: KYZZI-DOFEH-DAP23-NJHWU-GQ6KB
Uninstall: Uninstall-Kyzzi.bat (songs and settings are kept).
