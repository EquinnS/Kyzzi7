@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Setup-Kyzzi.ps1"
if errorlevel 1 echo. & echo Setup failed. See the message above.
pause
