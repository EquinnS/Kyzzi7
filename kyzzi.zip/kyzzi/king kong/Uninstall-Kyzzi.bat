@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Uninstall-Kyzzi.ps1"
pause
