# Removes Kyzzi's program files and shortcuts. Your songs (KyzziGdFolder), settings and key are kept.
$dst = Join-Path $env:LOCALAPPDATA "Kyzzi"
Remove-Item (Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs\Kyzzi.lnk") -ErrorAction SilentlyContinue
Remove-Item (Join-Path ([Environment]::GetFolderPath("Desktop")) "Kyzzi.lnk") -ErrorAction SilentlyContinue
foreach ($f in "kyzzi_app.py", "Kyzzi.exe", "icon.png", "kyzzi.ico") { Remove-Item (Join-Path $dst $f) -ErrorAction SilentlyContinue }
Write-Host "Kyzzi removed. Your songs and settings are still in $dst (delete that folder to remove them too)." -ForegroundColor Green
