# Kyzzi Pro installer: copies Kyzzi to %LOCALAPPDATA%\Kyzzi, activates the key, adds Start menu + Desktop shortcuts.
$ErrorActionPreference = "Stop"
$src = $PSScriptRoot
$dst = Join-Path $env:LOCALAPPDATA "Kyzzi"
Write-Host "Installing Kyzzi to $dst" -ForegroundColor Cyan
New-Item -ItemType Directory -Force $dst | Out-Null

$files = @("icon.png", "kyzzi.ico", "kyzzi.key", "Uninstall-Kyzzi.ps1")
$exeSrc = Join-Path $src "Kyzzi.exe"
$target = $null; $arguments = ""

if (Test-Path $exeSrc) {
    # A built Kyzzi.exe next to this installer is used if present.
    Copy-Item $exeSrc $dst -Force
    $target = Join-Path $dst "Kyzzi.exe"
} else {
    $files += "kyzzi_app.py"
    function Find-Python {
        $p = $null
        if (Get-Command py -ErrorAction SilentlyContinue) { $p = (& py -3 -c "import sys;print(sys.executable)" 2>$null) }
        if (-not $p -and (Get-Command python -ErrorAction SilentlyContinue)) { $p = (& python -c "import sys;print(sys.executable)" 2>$null) }
        if ($p -and (Test-Path $p)) { return $p }
        return $null
    }
    $py = Find-Python
    if (-not $py -and (Get-Command winget -ErrorAction SilentlyContinue)) {
        Write-Host "Python not found. Installing it with winget..." -ForegroundColor Yellow
        winget install -e --id Python.Python.3.12 --silent --accept-package-agreements --accept-source-agreements
        $guess = Get-ChildItem "$env:LOCALAPPDATA\Programs\Python" -Filter python.exe -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($guess) { $py = $guess.FullName } else { $py = Find-Python }
    }
    if (-not $py) { throw "Python 3 is required. Install it from https://www.python.org/downloads/ (tick 'Add python.exe to PATH'), then run Setup again." }
    Write-Host "Using Python: $py"
    try { & $py -m pip install --quiet pywebview } catch { Write-Host "pywebview not installed; Kyzzi will use an Edge/Chrome app window instead." -ForegroundColor Yellow }
    $pyw = $py -replace 'python\.exe$', 'pythonw.exe'
    if (-not (Test-Path $pyw)) { $pyw = $py }
    $target = $pyw
    $arguments = '"' + (Join-Path $dst "kyzzi_app.py") + '"'
}

foreach ($f in $files) { Copy-Item (Join-Path $src $f) $dst -Force }

function New-Shortcut($path, $targetPath, $argString) {
    $w = New-Object -ComObject WScript.Shell
    $s = $w.CreateShortcut($path)
    $s.TargetPath = $targetPath
    $s.Arguments = [string]$argString
    $s.WorkingDirectory = $dst
    $s.IconLocation = (Join-Path $dst "kyzzi.ico")
    $s.Description = "Kyzzi - Geometry Dash song manager"
    $s.Save()
}
$menu = Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs\Kyzzi.lnk"
$desk = Join-Path ([Environment]::GetFolderPath("Desktop")) "Kyzzi.lnk"
New-Shortcut $menu $target $arguments
New-Shortcut $desk $target $arguments

Write-Host "`nKyzzi installed. Your Pro key was activated from kyzzi.key on first launch." -ForegroundColor Green
Write-Host "Find Kyzzi on your Desktop and in the Start menu."
if ($arguments) { Start-Process -FilePath $target -ArgumentList $arguments -WorkingDirectory $dst }
else { Start-Process -FilePath $target -WorkingDirectory $dst }
